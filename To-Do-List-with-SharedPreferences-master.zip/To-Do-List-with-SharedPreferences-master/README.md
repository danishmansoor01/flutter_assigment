<h1>Task: To-Do List with SharedPreferences</h1>

<h5>Purpose:</h5>
<p>This task creates a to-do list app using SharedPreferences to save tasks persistently.</p>

Requirements:
<ul>
  <li>Dependencies: shared_preferences for data storage.</li>
  <li>Flutter SDK: Ensure Flutter is installed.</li>
</ul>

